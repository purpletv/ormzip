package eStoreProduct.DAO.admin;

public interface shipmentsDAO {

}
