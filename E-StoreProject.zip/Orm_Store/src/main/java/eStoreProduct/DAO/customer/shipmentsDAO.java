package eStoreProduct.DAO.customer;

import java.util.List;

import eStoreProduct.model.orderProductsModel;

public interface shipmentsDAO {
	
}
