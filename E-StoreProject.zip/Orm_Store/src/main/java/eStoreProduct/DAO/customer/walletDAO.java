package eStoreProduct.DAO.customer;


public interface walletDAO {
	public eStoreProduct.model.customer.entities.wallet getWalletAmount(int custid);

	public void updatewallet(double amt, int custid);

}
