package eStoreProduct.DAO.customer;

import eStoreProduct.model.admin.entities.*;

public interface EmailConfigDAO {
	void changeEmail(EmailConfigModel ecm);

	EmailConfigModel getEmail();
}