package eStoreProduct.DAO.customer;

public interface StockUpdaterDAO {
    void updateStocks(int prod_id, int qty);
}
