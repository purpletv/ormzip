package eStoreProduct.DAO.customer;

public interface ServicableRegionDAO {
	public boolean getValidityOfPincode(int pincode);
}
