package eStoreProduct.model.customer.entities;

public class emailModel {
	private String ename;
	private String mailId;
}